-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 13, 2022 at 06:56 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `servicecenter`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `user`, `password`) VALUES
(2, 'admin', 'admin1234');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `mobile` int(10) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `pid`, `email`, `name`, `address`, `mobile`, `status`) VALUES
(20, 13, 'sasindula@gmail.com', 'UDARATA RALLAGE ', 'J28/2,Weligalla RD\nGodagama,Mawanella', 774186332, 'assigned'),
(21, 14, 'sasindulakshithabandara@gmail.com', 'UDARATA RALLAGE SASINDU LAKSHITHA BANDARA', 'J28/2,Weligalla RD\nGodagama,Mawanella', 774186332, 'assigned'),
(22, 15, 'sasindulakshithabandara@gmail.com', 'Sasindu Bandara', 'J28/2,Weligalla RD, Godagama, Mawanella', 2147483647, 'assigned'),
(23, 16, 'sasindulakshithabandara@gmail.com', 'Sasindu Bandara', 'J28/2,Weligalla RD, Godagama, Mawanella', 2147483647, 'assigned'),
(24, 17, 'sasindulakshithabandara@gmail.com', 'Sasindu', 'sss', 774186332, 'assigned'),
(25, 18, 'sasindulakshithabandara@gmail.com', 'Sasindu Bnadara', 'J28/2,Weligalla RD', 774186332, 'assigned');

-- --------------------------------------------------------

--
-- Table structure for table `developer`
--

CREATE TABLE `developer` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` int(10) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `developer`
--

INSERT INTO `developer` (`id`, `name`, `email`, `mobile`, `position`, `password`) VALUES
(1, 'John', 'jhone@gmail.com', 77418560, 'Back-End development\r\n', '123456'),
(2, 'Kamr', 'kmne@gmail.com', 77418560, 'Back-End development', '123456'),
(3, 'John', 'one@gmail.com', 77418560, 'Full-Stack development', '123456'),
(4, 'Heri', 'here@gmail.com', 77418560, 'Front-End development', '123456\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `pid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `budget` varchar(20) DEFAULT NULL,
  `devId` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`pid`, `type`, `duration`, `budget`, `devId`, `description`, `status`) VALUES
(13, 'Front-End development\r\n', '10-15 Days', 'Rs1.000.00', 1, 'sadas', 'accepted'),
(14, 'Front-End development\r\n', '5-7 Days', 'Rs150.00', 1, 'sadsa', 'accepted'),
(15, 'Back-End development\r\n', '3 Month', 'Rs2.500.00', 3, 'I want build a website', ''),
(16, 'Software development', '5-7 Days', 'Rs50.000.00', 1, 'I want to develop a web page', 'accepted'),
(17, 'Electronic', '5-7 Days', 'Rs500.00', 1, 'looking for a web site', 'accepted'),
(18, 'Design', '20-25 Days', 'Rs25.000.00', 1, 'I want a web application to manage my company store of the clothes. And alos need to be a billing system for that.', 'accepted');

-- --------------------------------------------------------

--
-- Table structure for table `useraccount`
--

CREATE TABLE `useraccount` (
  `uname` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `developer`
--
ALTER TABLE `developer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `useraccount`
--
ALTER TABLE `useraccount`
  ADD PRIMARY KEY (`uname`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `developer`
--
ALTER TABLE `developer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
